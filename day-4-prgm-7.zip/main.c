/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
int main() 
{
   char str[100], new_str[100];
   int i, j = 0;
   printf("Enter a string: ");
   fgets(str, sizeof(str), stdin);
   for(i = 0; i < strlen(str); i++) 
   {
      if(str[i] != 'a' && str[i] != 'e' && str[i] != 'i' && str[i] != 'o' && str[i] != 'u'
         && str[i] != 'A' && str[i] != 'E' && str[i] != 'I' && str[i] != 'O' && str[i] != 'U') 
         {
         new_str[j] = str[i];
         j++;
      }
   }
   new_str[j] = '\0';
   printf("String after removing vowels: %s", new_str);
   return 0;
}
