/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<string.h>
union Data
{
    int i;
    float a;
    char str[20];
};
int main()
{
    union Data data;
data.i=10;
data.a=220.5;
strcpy(data.str,"c programming");
printf("data.i:%d\n",data.i);
printf("data.a:%f\n",data.a);
printf("data.str:%s\n",data.str);
return 0;
}