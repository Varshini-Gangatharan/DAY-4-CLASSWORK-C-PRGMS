/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
union data
{
    int integer;
    float floating_point;
};
int main()
{
    union data d;
    char input_type;
    printf("Enter the type(i for integer,f for floating_point):");
    scanf("%c",&input_type);
    if(input_type=='i')
    {
        printf("Enter the integer value:");
        scanf("%d",&d.integer);
        printf("The value you entered is:%d\n",d.integer);
    }
    else if(input_type=='f')
    {
        printf("Enter the floating value:");
        scanf("%f",&d.floating_point);
        printf("The value you entered is:%f\n",d.floating_point);
    }
    else
    {
        printf("Invalid type entered\n");
    }
    return 0;
}
