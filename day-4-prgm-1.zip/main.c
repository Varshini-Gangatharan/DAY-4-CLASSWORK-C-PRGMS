/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<conio.h>
struct employee{char name[20];int empid;float salary;};
int main()
{
    struct employee emp={"Varshini",2010,5000.15};
    printf("\nEmployee details are:");
    printf("\n%s",emp.name);
    printf("\n%d",emp.empid);
    printf("\n%f",emp.salary);
    return 0;
}

