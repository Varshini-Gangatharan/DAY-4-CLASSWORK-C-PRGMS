/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
#include<conio.h>
struct employee{char name[20];int empid;float salary;}ab;
int main()
{
    struct employee ab={"Varshini",2010,5000.15};
    printf("\nEmployee details are:");
    printf("\n%s",ab.name);
    printf("\n%d",ab.empid);
    printf("\n%f",ab.salary);
    return 0;
}

