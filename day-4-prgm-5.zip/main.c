/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<conio.h>
#include<string.h>
void main()
{
    char str[20];
    int i,j,len;
    printf("Enter the string:");
    scanf("%s",str);
    len=strlen(str);
    for(i=0;i<len;i++)
    {
      if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u' || str[i]=='A' ||str[i]=='E' || str[i]=='I' || str[i]=='O' || str[i]=='U')
      {
          for(j=i; j<len; j++)
         {
            str[j]=str[j+1];
         }
         i--;
         len--;
      }
    }
    printf("After Deleting:%s",str);
    scanf("%s",str);
}
































   