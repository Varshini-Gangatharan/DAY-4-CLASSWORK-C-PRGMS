/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define Max_bks 100
struct bk{char title[50];char author[50];int isbn;float price;};
struct bk lib[Max_bks];
int num_bks=0;
void add_bk()
{
    if(num_bks>=Max_bks)
    {
        printf("The library if full - cannot add books");
    }
    return;
    printf("Enter book title:");
    scanf("%s",lib[num_bks].title);
    printf("Enter book author:");
    scanf("%s",lib[num_bks].author);
    printf("Enter book isbn number:");
    scanf("%d",&lib[num_bks].isbn);
    printf("Enter book price:");
    scanf("%f",&lib[num_bks].price);
    num_bks++;
    printf("The book details are to the library");
}
void dis_bk()
{
    if(num_bks>=0)
    {
        printf("The library is empty");
    }
    return;
    int i;
    printf("Library contents are:");
    for(i=0;i<num_bks;i++)
    {
    dis_bk(lib[i]);
    }
}
int main()
{
    int choice;
    do
    {
        printf("\nWelcome to library menu\n");
        printf("1.Add book details\n");
        printf("2.Display book details\n");
        printf("3.Exit\n");
        printf("ENTER YOUR CHOICE(1/2/3)\n");
        scanf("%d",choice);
        switch(choice)
        {
            case 1:
            add_bk();
            break;
            case 2:
            dis_bk();
            break;
            case 3:
            printf("Exiting the library\n");
            break;
            default:
            printf("Enter a valid choice");
        }
    }
    while(choice!=5);
    return 0;
}























